import pygame
import random
import os
import asyncio  # Obrigatório para funcionamento Web

# 1. Configurações Iniciais
pygame.init()
largura, altura = 600, 480
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption('Snake Game Evolution - Welison Pro')
relogio = pygame.time.Clock()

# Cores
PRETO = (15, 15, 15)
BRANCO = (255, 255, 255)
VERDE_CABECA = (0, 180, 0)
VERDE_CORPO = (0, 255, 0)
VERMELHO = (255, 0, 0)
AMARELO = (255, 255, 0)

# Configurações do Jogo
tamanho_bloco = 20
velocidade_inicial = 10

# Fontes
fonte_placar = pygame.font.SysFont("arial", 22, bold=True)
fonte_status = pygame.font.SysFont("arial", 40, bold=True)
fonte_icones = pygame.font.SysFont("arial", 28, bold=True)


# --- SISTEMA DE RECORDE ---
def carregar_recorde():
    if not os.path.exists("recorde.txt"): return 0
    with open("recorde.txt", "r") as f:
        try:
            conteudo = f.read().strip()
            return int(conteudo) if conteudo else 0
        except:
            return 0


def salvar_recorde(pontos):
    if pontos > carregar_recorde():
        with open("recorde.txt", "w") as f:
            f.write(str(pontos))


# --- CONFIGURAÇÃO DA UI ---
tam_b = 60
margem = 20
botoes_pos = {
    'UP': (largura - tam_b * 2 - margem, altura - tam_b * 3 - margem),
    'DOWN': (largura - tam_b * 2 - margem, altura - tam_b - margem),
    'LEFT': (largura - tam_b * 3 - margem, altura - tam_b * 2 - margem),
    'RIGHT': (largura - tam_b - margem, altura - tam_b * 2 - margem)
}
btn_pausa_rect = pygame.Rect(largura - 60, 20, 45, 45)


def desenhar_ui(pontos, recorde, pausado):
    tela.blit(fonte_placar.render(f"PONTOS: {pontos}", True, AMARELO), [20, 20])
    tela.blit(fonte_placar.render(f"RECORDE: {recorde}", True, BRANCO), [20, 45])

    pygame.draw.rect(tela, (80, 80, 80), btn_pausa_rect, border_radius=10)
    txt_p = "||" if not pausado else "▶"
    tela.blit(fonte_icones.render(txt_p, True, BRANCO), (btn_pausa_rect.x + 12, btn_pausa_rect.y + 5))

    for direcao, pos in botoes_pos.items():
        centro = (pos[0] + tam_b // 2, pos[1] + tam_b // 2)
        pygame.draw.circle(tela, (255, 255, 255, 30), centro, tam_b // 2)
        pygame.draw.circle(tela, BRANCO, centro, tam_b // 2, 2)

        if direcao == 'UP':
            pts = [(centro[0], centro[1] - 15), (centro[0] - 12, centro[1] + 10), (centro[0] + 12, centro[1] + 10)]
        elif direcao == 'DOWN':
            pts = [(centro[0], centro[1] + 15), (centro[0] - 12, centro[1] - 10), (centro[0] + 12, centro[1] - 10)]
        elif direcao == 'LEFT':
            pts = [(centro[0] - 15, centro[1]), (centro[0] + 10, centro[1] - 12), (centro[0] + 10, centro[1] + 12)]
        elif direcao == 'RIGHT':
            pts = [(centro[0] + 15, centro[1]), (centro[0] - 10, centro[1] - 12), (centro[0] - 10, centro[1] + 12)]
        pygame.draw.polygon(tela, BRANCO, pts)


async def jogar():
    while True:  # Loop de reinicialização
        x, y = largura / 2, altura / 3
        dx, dy = 0, 0
        corpo_cobra = []
        comprimento_cobra = 1
        pontos = 0
        pausado = False
        game_over = False
        comida_x = round(random.randrange(0, largura - tamanho_bloco) / 20.0) * 20.0
        comida_y = round(random.randrange(80, altura - 200) / 20.0) * 20.0

        while True:  # Loop do jogo em si
            recorde_atual = carregar_recorde()

            for ev in pygame.event.get():
                if ev.type == pygame.QUIT: return
                if ev.type == pygame.MOUSEBUTTONDOWN:
                    if game_over:  # Se morreu, clica para sair do loop interno e reiniciar
                        game_over = False
                        break
                    if btn_pausa_rect.collidepoint(ev.pos): pausado = not pausado
                    if not pausado:
                        if pygame.Rect(botoes_pos['UP'], (tam_b, tam_b)).collidepoint(ev.pos) and dy == 0:
                            dx, dy = 0, -tamanho_bloco
                        elif pygame.Rect(botoes_pos['DOWN'], (tam_b, tam_b)).collidepoint(ev.pos) and dy == 0:
                            dx, dy = 0, tamanho_bloco
                        elif pygame.Rect(botoes_pos['LEFT'], (tam_b, tam_b)).collidepoint(ev.pos) and dx == 0:
                            dx, dy = -tamanho_bloco, 0
                        elif pygame.Rect(botoes_pos['RIGHT'], (tam_b, tam_b)).collidepoint(ev.pos) and dx == 0:
                            dx, dy = tamanho_bloco, 0

            # Lógica de movimentação
            if not pausado and not game_over:
                x += dx
                y += dy
                if x >= largura or x < 0 or y >= altura or y < 0: game_over = True

                cabeca = [x, y]
                corpo_cobra.append(cabeca)
                if len(corpo_cobra) > comprimento_cobra: del corpo_cobra[0]
                for bloco in corpo_cobra[:-1]:
                    if bloco == cabeca: game_over = True

                if x == comida_x and y == comida_y:
                    comida_x = round(random.randrange(0, largura - tamanho_bloco) / 20.0) * 20.0
                    comida_y = round(random.randrange(80, altura - 200) / 20.0) * 20.0
                    comprimento_cobra += 1
                    pontos += 10
                    salvar_recorde(pontos)

            # Desenho da tela
            tela.fill(PRETO)
            if not game_over:
                pygame.draw.circle(tela, VERMELHO, (int(comida_x + 10), int(comida_y + 10)), 9)
                for i, bloco in enumerate(corpo_cobra):
                    cor = VERDE_CABECA if i == len(corpo_cobra) - 1 else VERDE_CORPO
                    pygame.draw.rect(tela, cor, [bloco[0], bloco[1], tamanho_bloco - 1, tamanho_bloco - 1],
                                     border_radius=5)
            else:
                txt_go = fonte_status.render("GAME OVER", True, VERMELHO)
                txt_re = fonte_placar.render("Toque para reiniciar", True, BRANCO)
                tela.blit(txt_go, (largura // 2 - 110, altura // 2 - 50))
                tela.blit(txt_re, (largura // 2 - 90, altura // 2 + 10))

            desenhar_ui(pontos, recorde_atual, pausado)
            if pausado:
                tela.blit(fonte_status.render("PAUSADO", True, AMARELO), [largura / 2 - 80, altura / 2 - 20])

            pygame.display.update()
            relogio.tick(velocidade_inicial + (pontos // 50))
            await asyncio.sleep(0)

            # Se saiu do loop de eventos para reiniciar
            if not any(corpo_cobra) and not game_over: break

            # Pequeno delay antes de reiniciar de fato
        await asyncio.sleep(0.1)


# Início do programa
if __name__ == "__main__":
    asyncio.run(jogar())
import pygame
import random
import os
import asyncio  # Obrigatório para funcionamento Web

# ==========================================
# 1. Configurações Globais e Inicialização
# ==========================================
pygame.init()
LARGURA, ALTURA = 600, 480
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption('Snake Game Evolution - Welison Mobile Fit')
relogio = pygame.time.Clock()

# Paleta de Cores Profissional
COR_FUNDO = (15, 15, 15)
COR_CABECA = (0, 180, 0)
COR_CORPO = (0, 255, 0)
COR_COMIDA = (255, 50, 50)  # Vermelho mais suave
COR_TEXTO_PRINCIPAL = (255, 255, 255)
COR_PONTOS = (255, 255, 100)  # Amarelo suave
COR_UI_BASE = (255, 255, 255)  # Branco para elementos de UI

# Configurações do Jogo
TAMANHO_BLOCO = 20
VELOCIDADE_BASE = 10

# Fontes
try:
    fonte_placar = pygame.font.SysFont("arial", 24, bold=True)
    fonte_main = pygame.font.SysFont("arial", 48, bold=True)
except:
    fonte_placar = pygame.font.SysFont(None, 24)
    fonte_main = pygame.font.SysFont(None, 48)


# --- SISTEMA DE RECORDE ---
def carregar_recorde():
    if not os.path.exists("recorde.txt"): return 0
    with open("recorde.txt", "r") as f:
        try:
            conteudo = f.read().strip()
            return int(conteudo) if conteudo else 0
        except:
            return 0


def salvar_recorde(pontos):
    if pontos > carregar_recorde():
        with open("recorde.txt", "w") as f:
            f.write(str(pontos))


# ==========================================
# 2. Configuração e Desenho da UI (Aparência Restaurada)
# ==========================================
# Configurações Mobile Fit do D-Pad
tam_b = 65  # Botões grandes para celular
margem = 20
botoes_pos = {
    'UP': (LARGURA - tam_b * 2 - margem, ALTURA - tam_b * 3 - margem),
    'DOWN': (LARGURA - tam_b * 2 - margem, ALTURA - tam_b - margem),
    'LEFT': (LARGURA - tam_b * 3 - margem, ALTURA - tam_b * 2 - margem),
    'RIGHT': (LARGURA - tam_b - margem, ALTURA - tam_b * 2 - margem)
}
btn_pausa_rect = pygame.Rect(LARGURA - 65, 20, 50, 50)


def desenhar_controles(superficie, pontos, recorde, pausado):
    # Placar e Recorde (Canto superior esquerdo)
    superficie.blit(fonte_placar.render(f"PONTOS: {pontos}", True, COR_PONTOS), [25, 25])
    superficie.blit(fonte_placar.render(f"RECORDE: {recorde}", True, COR_TEXTO_PRINCIPAL), [25, 55])

    # Botão de Pausa (Transparente e Elegante)
    s_pausa = pygame.Surface((50, 50), pygame.SRCALPHA)
    pygame.draw.rect(s_pausa, (100, 100, 100, 150), s_pausa.get_rect(), border_radius=12)
    txt_p = "||" if not pausado else "▶"
    s_pausa.blit(fonte_placar.render(txt_p, True, COR_TEXTO_PRINCIPAL), (15, 12))
    superficie.blit(s_pausa, btn_pausa_rect)

    # D-Pad Mobile Fit (Círculos Transparentes e Setas Geométricas)
    for direcao, pos in botoes_pos.items():
        s_btn = pygame.Surface((tam_b, tam_b), pygame.SRCALPHA)
        # Círculo de fundo transparente (alfa 60)
        pygame.draw.circle(s_btn, (255, 255, 255, 60), (tam_b // 2, tam_b // 2), tam_b // 2)
        # Borda branca sólida
        pygame.draw.circle(s_btn, COR_UI_BASE, (tam_b // 2, tam_b // 2), tam_b // 2, 3)

        # Desenho Geométrico das Setas
        centro = (tam_b // 2, tam_b // 2)
        offset = 15  # Tamanho da seta
        if direcao == 'UP':
            pts = [(centro[0], centro[1] - offset), (centro[0] - offset, centro[1] + offset // 2),
                   (centro[0] + offset, centro[1] + offset // 2)]
        elif direcao == 'DOWN':
            pts = [(centro[0], centro[1] + offset), (centro[0] - offset, centro[1] - offset // 2),
                   (centro[0] + offset, centro[1] - offset // 2)]
        elif direcao == 'LEFT':
            pts = [(centro[0] - offset, centro[1]), (centro[0] + offset // 2, centro[1] - offset),
                   (centro[0] + offset // 2, centro[1] + offset)]
        elif direcao == 'RIGHT':
            pts = [(centro[0] + offset, centro[1]), (centro[0] - offset // 2, centro[1] - offset),
                   (centro[0] - offset // 2, centro[1] + offset)]

        pygame.draw.polygon(s_btn, COR_UI_BASE, pts)
        superficie.blit(s_btn, pos)


# ==========================================
# 3. Função Principal Assíncrona (Lógica Corrigida)
# ==========================================
async def jogar():
    # Variáveis de Estado do Jogo (Resetadas a cada chamada de jogar())
    x, y = LARGURA / 2, ALTURA / 3
    dx, dy = 0, 0
    corpo_cobra = []
    comprimento_cobra = 1
    pontos = 0
    pausado = False
    game_over = False
    jogo_encerrado = False

    # Posição inicial da comida
    comida_x = round(random.randrange(0, LARGURA - TAMANHO_BLOCO) / 20.0) * 20.0
    comida_y = round(random.randrange(80, ALTURA - 200) / 20.0) * 20.0

    while not jogo_encerrado:
        recorde_atual = carregar_recorde()

        # 3.1 Processamento de Eventos
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                pygame.quit()
                return  # Encerra o programa

            if ev.type == pygame.MOUSEBUTTONDOWN:
                # SE MORREU: Qualquer toque na tela reinicia
                if game_over:
                    # Chamar jogar() recursivamente resetará todos os estados
                    await jogar()
                    return  # Importante: Sair desta instância da função

                # SE JOGANDO: Lógica de controles
                if btn_pausa_rect.collidepoint(ev.pos):
                    pausado = not pausado

                if not pausado:
                    # Verificação de clique nos botões do D-Pad
                    rect_up = pygame.Rect(botoes_pos['UP'], (tam_b, tam_b))
                    rect_down = pygame.Rect(botoes_pos['DOWN'], (tam_b, tam_b))
                    rect_left = pygame.Rect(botoes_pos['LEFT'], (tam_b, tam_b))
                    rect_right = pygame.Rect(botoes_pos['RIGHT'], (tam_b, tam_b))

                    if rect_up.collidepoint(ev.pos) and dy == 0:
                        dx, dy = 0, -TAMANHO_BLOCO
                    elif rect_down.collidepoint(ev.pos) and dy == 0:
                        dx, dy = 0, TAMANHO_BLOCO
                    elif rect_left.collidepoint(ev.pos) and dx == 0:
                        dx, dy = -TAMANHO_BLOCO, 0
                    elif rect_right.collidepoint(ev.pos) and dx == 0:
                        dx, dy = TAMANHO_BLOCO, 0

        # 3.2 Lógica do Jogo (Apenas se não estiver pausado e não for Game Over)
        if not pausado and not game_over:
            x += dx
            y += dy

            # Colisão com as bordas
            if x >= LARGURA or x < 0 or y >= ALTURA or y < 0:
                game_over = True

            # Lógica do corpo da cobra
            cabeca = [x, y]
            corpo_cobra.append(cabeca)
            if len(corpo_cobra) > comprimento_cobra:
                del corpo_cobra[0]

            # Auto-colisão
            for bloco in corpo_cobra[:-1]:
                if bloco == cabeca:
                    game_over = True

            # Comer a comida
            if x == comida_x and y == comida_y:
                comida_x = round(random.randrange(0, LARGURA - TAMANHO_BLOCO) / 20.0) * 20.0
                comida_y = round(random.randrange(80, ALTURA - 200) / 20.0) * 20.0
                comprimento_cobra += 1
                pontos += 10
                salvar_recorde(pontos)

        # 3.3 Renderização (Desenho na tela)
        tela.fill(COR_FUNDO)

        # Desenhar elementos do jogo apenas se NÃO for Game Over
        if not game_over:
            # Comida
            pygame.draw.circle(tela, COR_COMIDA, (int(comida_x + 10), int(comida_y + 10)), 9)
            # Cobra
            for i, bloco in enumerate(corpo_cobra):
                # Cor diferente para a cabeça
                cor = COR_CABECA if i == len(corpo_cobra) - 1 else COR_CORPO
                # Desenhar bloco arredondado (border_radius)
                pygame.draw.rect(tela, cor, [bloco[0], bloco[1], TAMANHO_BLOCO - 1, TAMANHO_BLOCO - 1], border_radius=6)
        else:
            # TELA DE GAME OVER (Simples e Direta)
            txt_go = fonte_main.render("GAME OVER", True, COR_COMIDA)
            txt_re = fonte_placar.render("Toque na tela para reiniciar", True, COR_TEXTO_PRINCIPAL)
            # Centralizar texto
            tela.blit(txt_go, (LARGURA // 2 - 130, ALTURA // 2 - 50))
            tela.blit(txt_re, (LARGURA // 2 - 125, ALTURA // 2 + 15))

        # Desenhar UI (Controles) por cima de tudo
        desenhar_controles(tela, pontos, recorde_atual, pausado)

        if pausado and not game_over:
            tela.blit(fonte_main.render("PAUSADO", True, COR_PONTOS), [LARGURA / 2 - 100, ALTURA / 2 - 25])

        # Atualizar a tela
        pygame.display.update()

        # Controlar FPS (velocidade aumenta com pontos)
        relogio.tick(VELOCIDADE_BASE + (pontos // 50))

        # O SEGREDO PARA A WEB: await asyncio.sleep(0)
        await asyncio.sleep(0)


# ==========================================
# 4. Início do Programa
# ==========================================
if __name__ == "__main__":
    asyncio.run(jogar())
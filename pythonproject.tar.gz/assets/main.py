import pygame
import random
import os
import asyncio

# 1. Configurações e Cores
pygame.init()
LARGURA, ALTURA = 600, 480
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption('Snake Game - Welison Premium Edition')
relogio = pygame.time.Clock()

PRETO, BRANCO, VERMELHO = (15, 15, 15), (255, 255, 255), (255, 50, 50)
VERDE_CABECA, VERDE_CORPO, AMARELO = (0, 180, 0), (0, 255, 0), (255, 255, 100)

TAMANHO_BLOCO = 20
VELOCIDADE_BASE = 10

fonte_placar = pygame.font.SysFont("arial", 22, bold=True)
fonte_status = pygame.font.SysFont("arial", 40, bold=True)


# --- SISTEMA DE RECORDE ---
def carregar_recorde():
    if not os.path.exists("recorde.txt"): return 0
    with open("recorde.txt", "r") as f:
        try:
            return int(f.read().strip())
        except:
            return 0


def salvar_recorde(pontos):
    if pontos > carregar_recorde():
        with open("recorde.txt", "w") as f: f.write(str(pontos))


def resetar_recorde():
    if os.path.exists("recorde.txt"): os.remove("recorde.txt")


# --- UI E BOTÕES ---
tam_b = 65
margem = 20
botoes_pos = {
    'UP': (LARGURA - tam_b * 2 - margem, ALTURA - tam_b * 3 - margem),
    'DOWN': (LARGURA - tam_b * 2 - margem, ALTURA - tam_b - margem),
    'LEFT': (LARGURA - tam_b * 3 - margem, ALTURA - tam_b * 2 - margem),
    'RIGHT': (LARGURA - tam_b - margem, ALTURA - tam_b * 2 - margem)
}
btn_pausa_rect = pygame.Rect(LARGURA - 65, 20, 50, 50)
# Novo botão para resetar recorde no celular (ícone de lixeira/X)
btn_reset_rect = pygame.Rect(20, 85, 100, 35)


def desenhar_ui(pontos, recorde, pausado):
    # Textos
    tela.blit(fonte_placar.render(f"PONTOS: {pontos}", True, AMARELO), [20, 20])
    tela.blit(fonte_placar.render(f"RECORDE: {recorde}", True, BRANCO), [20, 50])

    # Botão Resetar (Para Celular)
    pygame.draw.rect(tela, (200, 50, 50), btn_reset_rect, border_radius=8)
    tela.blit(fonte_placar.render("Zerar Recorde", True, BRANCO), (btn_reset_rect.x + 5, btn_reset_rect.y + 5))

    # Botão Pausa
    pygame.draw.rect(tela, (80, 80, 80), btn_pausa_rect, border_radius=12)
    txt_p = "||" if not pausado else "▶"
    tela.blit(fonte_placar.render(txt_p, True, BRANCO), (btn_pausa_rect.x + 18, btn_pausa_rect.y + 12))

    # D-Pad (Setas Geométricas com Transparência)
    for direcao, pos in botoes_pos.items():
        centro = (pos[0] + tam_b // 2, pos[1] + tam_b // 2)
        s = pygame.Surface((tam_b, tam_b), pygame.SRCALPHA)
        pygame.draw.circle(s, (255, 255, 255, 40), (tam_b // 2, tam_b // 2), tam_b // 2)
        pygame.draw.circle(s, BRANCO, (tam_b // 2, tam_b // 2), tam_b // 2, 2)

        offset = 12
        if direcao == 'UP':
            pts = [(tam_b // 2, 15), (tam_b // 2 - offset, 40), (tam_b // 2 + offset, 40)]
        elif direcao == 'DOWN':
            pts = [(tam_b // 2, 50), (tam_b // 2 - offset, 25), (tam_b // 2 + offset, 25)]
        elif direcao == 'LEFT':
            pts = [(15, tam_b // 2), (40, tam_b // 2 - offset), (40, tam_b // 2 + offset)]
        elif direcao == 'RIGHT':
            pts = [(50, tam_b // 2), (25, tam_b // 2 - offset), (25, tam_b // 2 + offset)]
        pygame.draw.polygon(s, BRANCO, pts)
        tela.blit(s, pos)


async def jogar():
    x, y = LARGURA / 2, ALTURA / 3
    dx, dy = 0, 0
    corpo_cobra, comprimento_cobra = [], 1
    pontos, pausado, game_over = 0, False, False
    comida_x = round(random.randrange(0, LARGURA - 20) / 20.0) * 20.0
    comida_y = round(random.randrange(120, ALTURA - 200) / 20.0) * 20.0

    while True:
        recorde_atual = carregar_recorde()
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT: return
            if ev.type == pygame.MOUSEBUTTONDOWN:
                if game_over: await jogar(); return
                if btn_pausa_rect.collidepoint(ev.pos): pausado = not pausado
                if btn_reset_rect.collidepoint(ev.pos): resetar_recorde()  # Reset por clique!

                if not pausado:
                    if pygame.Rect(botoes_pos['UP'], (tam_b, tam_b)).collidepoint(ev.pos) and dy == 0:
                        dx, dy = 0, -20
                    elif pygame.Rect(botoes_pos['DOWN'], (tam_b, tam_b)).collidepoint(ev.pos) and dy == 0:
                        dx, dy = 0, 20
                    elif pygame.Rect(botoes_pos['LEFT'], (tam_b, tam_b)).collidepoint(ev.pos) and dx == 0:
                        dx, dy = -20, 0
                    elif pygame.Rect(botoes_pos['RIGHT'], (tam_b, tam_b)).collidepoint(ev.pos) and dx == 0:
                        dx, dy = 20, 0

        if not pausado and not game_over:
            x += dx
            y += dy
            if x >= LARGURA or x < 0 or y >= ALTURA or y < 0: game_over = True

            cabeca = [x, y]
            corpo_cobra.append(cabeca)
            if len(corpo_cobra) > comprimento_cobra: del corpo_cobra[0]
            for bloco in corpo_cobra[:-1]:
                if bloco == cabeca: game_over = True

            if x == comida_x and y == comida_y:
                comida_x = round(random.randrange(0, LARGURA - 20) / 20.0) * 20.0
                comida_y = round(random.randrange(120, ALTURA - 200) / 20.0) * 20.0
                comprimento_cobra += 1;
                pontos += 10;
                salvar_recorde(pontos)

        tela.fill(PRETO)
        if not game_over:
            pygame.draw.circle(tela, VERMELHO, (int(comida_x + 10), int(comida_y + 10)), 9)
            for i, bloco in enumerate(corpo_cobra):
                cor = VERDE_CABECA if i == len(corpo_cobra) - 1 else VERDE_CORPO
                pygame.draw.rect(tela, cor, [bloco[0], bloco[1], 19, 19], border_radius=5)
                # --- OS OLHINHOS VOLTARAM ---
                if i == len(corpo_cobra) - 1:
                    pygame.draw.circle(tela, BRANCO, (int(bloco[0] + 6), int(bloco[1] + 6)), 3)
                    pygame.draw.circle(tela, BRANCO, (int(bloco[0] + 14), int(bloco[1] + 6)), 3)
        else:
            tela.blit(fonte_status.render("GAME OVER", True, VERMELHO), (LARGURA // 2 - 110, ALTURA // 2 - 40))
            tela.blit(fonte_placar.render("Toque para reiniciar", True, BRANCO), (LARGURA // 2 - 95, ALTURA // 2 + 20))

        desenhar_ui(pontos, recorde_atual, pausado)
        pygame.display.update()
        relogio.tick(VELOCIDADE_BASE + (pontos // 50))
        await asyncio.sleep(0)


asyncio.run(jogar())